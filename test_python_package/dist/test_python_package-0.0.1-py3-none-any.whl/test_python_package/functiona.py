def len(x1,x2):
    return (x1+x2)*2

def sum(x1,x2):
    return (x1+x2)